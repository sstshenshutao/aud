package frame;
/*
 * EntryInterface.java
 * 
 */


public interface EntryInterface {
    void setKey(String newKey);
    void setData(String newData);
    String getKey();
    String getData();
    String toString();
}
